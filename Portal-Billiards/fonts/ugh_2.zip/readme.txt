use this font however you want.
crediting me would be nice however!